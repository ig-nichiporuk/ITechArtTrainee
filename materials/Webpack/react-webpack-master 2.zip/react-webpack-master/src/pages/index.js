import HomePage from './home/container';
import DetailsPage from './details/container';

export {
  HomePage,
  DetailsPage,
};
