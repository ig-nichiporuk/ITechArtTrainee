import React from 'react';

import HomeView from './view';

const HomeContainer = () => <HomeView />;

export default HomeContainer;
