import React from 'react';

const DetailsView = () => (
  <div>
    <h1>My Details</h1>
  </div>
);

export default DetailsView;
