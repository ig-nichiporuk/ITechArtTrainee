import React from 'react';

import DetailsView from './view';

const DetailsContainer = () => <DetailsView />;

export default DetailsContainer;
