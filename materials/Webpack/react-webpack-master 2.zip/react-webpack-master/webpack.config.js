const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');

module.exports = (env, argv) => {
  const isProd = argv.mode === 'production';

  return {
    context: path.resolve(__dirname, 'src'), // место, где лежат все исходники
    mode: 'development',
    // mode: 'production',
    entry: './index.js',
    output: {
      // паттерны: name - имя файла, contenthash - создаёт название файла основывясь на контенте файла
      filename: isProd ? '[name]webpack.[contenthash].js' : '[name].[hash].js',
      // __dirname - текущая директория
      path: path.join(__dirname, 'build'),
    },
    plugins: [
      new HtmlWebpackPlugin({
        template: './index.html',
        minify: {
          collapseWhitespace: isProd // oптимизация
        }
      }),
      new CleanWebpackPlugin()
    ],
    module: {
      rules: [
        {
          test: /\.css$/,
          use: ['style-loader', 'css-loader'], // выполняются справа налево
        },
        {
          test: /\.(js|jsx)$/,
          exclude: /node_modules/, // не компилируем
          use: {
            loader: 'babel-loader',
          },
        },
        {
          test: /\.ts$/,
          exclude: /node_modules/, // не компилируем
          use: {
            loader: 'babel-loader',
            options: {
              presets: [
                '@babel/preset-env',
                '@babel/preset-typescript'
              ],
              plugins: [
                '@babel/plugin-proposal-class-properties'
              ]
            }
          },
        },
        {
          test: /\.(png|jpe?g|svg)$/,
          use: {
            loader: 'file-loader',
            options: {
              name: '[path][name]-[hash:8].[ext]',
            },
          },
        },
        {
          test: /\.(js|jsx|ts|tsx)$/,
          exclude: /node_modules/,
          enforce: 'pre',
          loader: 'eslint-loader',
        },
      ],
    },
    devServer: {
      contentBase: './build',
      hot: !isProd,
      port: 3000
    },
    resolve: {
      modules: [
        path.resolve(__dirname, './src'),
        path.resolve(__dirname, './images'),
        'node_modules',
      ],
      extensions: ['.js', '.jsx', '.ts', '.json'], // помогает избавиться от  расширений в импортах
      alias: {
        '@navigation': path.resolve(__dirname, './src/navigation'),
        '@pages': path.resolve(__dirname, './src/pages'),
        '@images': path.resolve(__dirname, './images'),
      },
    },
    optimization: {
      moduleIds: 'hashed',
      runtimeChunk: 'single',
      splitChunks: {
        cacheGroups: {
          vendor: {
            test: /[\\/]node_modules[\\/]/,
            name: 'vendors',
            chunks: 'all',
          },
        },
      },
    },
    devtool: 'inline-cheap-source-map',
  };
};
