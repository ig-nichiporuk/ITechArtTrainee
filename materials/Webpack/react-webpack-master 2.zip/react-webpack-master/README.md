# React with Webpack project example
The whole code is in `master` branch.

### How to run
1. Install dependencies: `npm install`
2. Run project in `development` mode: `npm run dev`

### Production mode
To build project in `production` mode you can use such command: `npm run build`.
Built code will be in the `build` folder of the root directory.
